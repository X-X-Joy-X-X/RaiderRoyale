# DebugScripts

Scripts in this folder are used to debug the transport


## For developers

To use these scripts locally update the cert paths to keys that you have locally. 

Certs for unity need to be signed by a CA, to make yourself a CA see https://stackoverflow.com/a/60516812/8479976

It also helps to set `MirrorLocal` your host file to point to an ip address of another pc on your local networks
