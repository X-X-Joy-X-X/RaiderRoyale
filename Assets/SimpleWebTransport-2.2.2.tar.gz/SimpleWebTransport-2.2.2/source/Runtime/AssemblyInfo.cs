using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("2.2.2")]

[assembly: InternalsVisibleTo("SimpleWebTransport.Tests.Runtime")]
[assembly: InternalsVisibleTo("SimpleWebTransport.Tests.Editor")]
