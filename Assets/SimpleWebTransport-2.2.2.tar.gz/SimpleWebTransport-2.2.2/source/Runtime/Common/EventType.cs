namespace JamesFrowen.SimpleWeb
{
    public enum EventType
    {
        Connected,
        Data,
        Disconnected,
        Error
    }
}
